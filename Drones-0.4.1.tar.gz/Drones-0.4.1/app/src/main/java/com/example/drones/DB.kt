import android.os.AsyncTask
import java.sql.Connection
import java.sql.DriverManager
import java.sql.SQLException
import Config

class DB(private val callback: DatabaseCallback) {

    private var connection: Connection? = null
    private val url = Config.DB_URL
    private val user = Config.DB_USER
    private val password = Config.DB_PASSWORD

    init {
        ConnectTask(this@DB).execute()
    }

    private fun createUsersTable() {
        val query = "CREATE TABLE IF NOT EXISTS users (id SERIAL PRIMARY KEY, username VARCHAR(255), password VARCHAR(255))"
        connection?.createStatement()?.execute(query)
    }

    fun insertUser(email: String, password: String) {
        InsertUserTask().execute(email, password)
    }

    fun isUserExist(username: String): Boolean {
        return IsUserExistTask().execute(username).get()
    }

    fun isUserPasswordExist(username: String, password: String): Boolean {
        return CheckUserPasswordTask().execute(Pair(username, password)).get()
    }

    fun closeConnection() {
        CloseConnectionTask().execute()
    }

    private companion object {
        private class ConnectTask(private val db: DB) : AsyncTask<Void, Void, Boolean>() {
            @Deprecated("Deprecated in Java")
            override fun doInBackground(vararg params: Void?): Boolean {
                return try {
                    Class.forName("org.postgresql.Driver")
                    db.connection = DriverManager.getConnection(db.url, db.user, db.password)
                    db.createUsersTable()
                    true
                } catch (e: ClassNotFoundException) {
                    e.printStackTrace()
                    false
                } catch (e: SQLException) {
                    e.printStackTrace()
                    false
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onPostExecute(result: Boolean) {
                if (!result) {
                    db.callback.onDatabaseError("Failed to connect to the database")
                }
            }
        }
    }

    private inner class InsertUserTask : AsyncTask<String, Void, Unit>() {
        @Deprecated("Deprecated in Java")
        override fun doInBackground(vararg params: String?) {
            val email = params[0]
            val password = params[1]
            val query = "INSERT INTO users (username, password) VALUES (?, ?)"
            connection?.prepareStatement(query)?.use { statement ->
                statement.setString(1, email)
                statement.setString(2, password)
                statement.executeUpdate()
            }
        }
    }


    private inner class IsUserExistTask : AsyncTask<String, Void, Boolean>() {
        @Deprecated("Deprecated in Java")
        override fun doInBackground(vararg params: String?): Boolean {
            val username = params[0]
            val query = "SELECT COUNT(*) FROM users WHERE username = ?"
            connection?.prepareStatement(query)?.use { statement ->
                statement.setString(1, username)
                val resultSet = statement.executeQuery()
                resultSet.next()
                val count = resultSet.getInt(1)
                return count > 0
            }
            return false
        }

        @Deprecated("Deprecated in Java")
        override fun onPostExecute(result: Boolean) {
            callback.onUserExistCheck(result)
        }
    }


    private inner class CheckUserPasswordTask : AsyncTask<Pair<String, String>, Void, Boolean>() {
        private var userExists: Boolean = false
        private var userPasswordExist: Boolean = false

        @Deprecated("Deprecated in Java")
        override fun doInBackground(vararg params: Pair<String, String>?): Boolean? {
            val username = params[0]?.first
            val password = params[0]?.second
            val userQuery = "SELECT COUNT(*) FROM users WHERE username = ?"
            connection?.prepareStatement(userQuery)?.use { statement ->
                statement.setString(1, username)
                val resultSet = statement.executeQuery()
                resultSet.next()
                val count = resultSet.getInt(1)
                userExists = count > 0
                if (!userExists){
                    userPasswordExist = userExists
                    return false
                }
            }
            val userPasswordQuery = "SELECT COUNT(*) FROM users WHERE username = ? AND password = ?"
            connection?.prepareStatement(userPasswordQuery)?.use { statement ->
                statement.setString(1, username)
                statement.setString(2, password)
                val resultSet = statement.executeQuery()
                resultSet.next()
                val count = resultSet.getInt(1)
                if (count > 0){
                    userExists = true;
                    userPasswordExist = true;
                    return true
                }
            }
            return false
        }
        @Deprecated("Deprecated in Java")
        override fun onPostExecute(result: Boolean) {
            callback.onUserPasswordChecked(userExists, userPasswordExist)
        }
    }

    private inner class CloseConnectionTask : AsyncTask<Void, Void, Unit>() {
        @Deprecated("Deprecated in Java")
        override fun doInBackground(vararg params: Void?) {
            connection?.close()
        }
    }

    interface DatabaseCallback {
        fun onUserPasswordChecked(userExists: Boolean, userPasswordExist: Boolean)
        fun onUserExistCheck(userExists: Boolean)
        fun onDatabaseError(errorMessage: String)
    }
}
