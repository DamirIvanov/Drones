package com.example.drones

import android.os.Bundle
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity


class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home)

        val editTextData1 = findViewById<EditText>(R.id.editText_data1)
        val editTextData2 = findViewById<EditText>(R.id.editText_data2)
        val editTextData3 = findViewById<EditText>(R.id.editText_data3)

        val data1 = editTextData1.text.toString()
        val data2 = editTextData2.text.toString()
        val data3 = editTextData3.text.toString()


    }
}