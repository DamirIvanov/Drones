object Config {
    const val DB_URL = "jdbc:postgresql://94.241.172.202:5432/postgres"
    const val DB_USER = "postgres"
    const val DB_PASSWORD = "postgres"
}
