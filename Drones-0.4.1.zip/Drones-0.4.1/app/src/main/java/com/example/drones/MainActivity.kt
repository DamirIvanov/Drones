package com.example.drones

import DB
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity(), DB.DatabaseCallback {

    private lateinit var usernameEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var repasswordEditText: EditText
    private lateinit var registerButton: Button

    private lateinit var database: DB

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        database = DB(this)

        usernameEditText = findViewById(R.id.username)
        passwordEditText = findViewById(R.id.password)
        repasswordEditText = findViewById(R.id.repassword)
        registerButton = findViewById(R.id.registerButton)

        registerButton.setOnClickListener {
            val username = usernameEditText.text.toString()
            val password = passwordEditText.text.toString()
            val repassword = repasswordEditText.text.toString()

            if (password != repassword) {
                Toast.makeText(applicationContext, "Password and RePassword does not fit", Toast.LENGTH_SHORT).show();
                return@setOnClickListener
            }
            else if (database.isUserExist(username)) {
                val intent = Intent(applicationContext, LoginActivity::class.java)
                startActivity(intent)
            }
            else{
                database.insertUser(username, password)
                val intent = Intent(applicationContext, LoginActivity::class.java)
                startActivity(intent)
            }
        }
    }

    override fun onUserExistCheck(userExists: Boolean) {
        if (userExists) {
            Toast.makeText(applicationContext, "User already exists! Please sign in", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(applicationContext, "Registered successfully. Please Sign In", Toast.LENGTH_SHORT).show();
        }
    }
    override fun onUserPasswordChecked(userExists: Boolean, userPasswordExist: Boolean) {
        if (userPasswordExist){
            Toast.makeText(applicationContext, "Successfully logged in", Toast.LENGTH_SHORT).show();
        }
        else if (userExists) {
            Toast.makeText(applicationContext, "You have dialed incorrect password", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(applicationContext, "User with such username not exist", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDatabaseError(errorMessage: String) {
        Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
    }

}
