package com.example.drones

import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import android.widget.EditText
import DB
import android.content.Intent
import android.widget.Toast

class LoginActivity : AppCompatActivity(), DB.DatabaseCallback {
    private lateinit var usernameEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var login_button: Button
    private lateinit var database: DB
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        database = DB(this)

        usernameEditText = findViewById(R.id.username_login)
        passwordEditText = findViewById(R.id.password_login)
        login_button =  findViewById(R.id.login)


        login_button.setOnClickListener{
            val username = usernameEditText.text.toString()
            val password = passwordEditText.text.toString()
            if (database.isUserPasswordExist(username, password)){
                val intent = Intent(applicationContext, TableActivity::class.java)
                startActivity(intent)
            }
            else {
                // Показать пользователю сообщение об ошибке
                //Toast.makeText(applicationContext, "Invalid username or password", Toast.LENGTH_SHORT).show()
                // Очистить поля ввода, если это необходимо
//                usernameEditText.text.clear()
//                passwordEditText.text.clear()
//                val intent = Intent(applicationContext, LoginActivity::class.java)
//                startActivity(intent)
            }
        }

    }

    override fun onUserExistCheck(userExists: Boolean) {
        if (userExists) {
            Toast.makeText(applicationContext, "Successfully logged in", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "User with such username not exist", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDatabaseError(errorMessage: String) {
        Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
    }

    override fun onUserPasswordChecked(userExists: Boolean, userPasswordExist: Boolean) {
        if (userPasswordExist){
            Toast.makeText(applicationContext, "Successfully logged in", Toast.LENGTH_SHORT).show();
        }
        else if (userExists) {
            Toast.makeText(applicationContext, "You have dialed incorrect password", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(applicationContext, "User with such username not exist", Toast.LENGTH_SHORT).show()

        }
    }
}