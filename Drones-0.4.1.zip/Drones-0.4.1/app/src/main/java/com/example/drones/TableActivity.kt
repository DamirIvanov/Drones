package com.example.drones

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TableRow
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class TableActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_table)

    }

    fun submitDataToServer(view: View) {
        val row1 = findViewById<TableRow>(R.id.row_1)

        // Находим внутри строки нужные элементы по их id
        val actualValue1 = row1.findViewById<EditText>(R.id.actual_value).text.toString()
        val note1 = row1.findViewById<EditText>(R.id.note).text.toString()
        println("note1 $note1 actualValue1 $actualValue1")


//        val row1_1 = findViewById<TableRow>(R.id.row_1_1)
//
//        // Находим внутри строки нужные элементы по их id
//        val actualValue = row1_1.findViewById<EditText>(R.id.actual_value).text.toString()
//        val note = row1_1.findViewById<EditText>(R.id.note).text.toString()
//        println("note $note actualValue $actualValue")

//        val actualValue1 = findViewById<EditText>(R.id.1-actual-value).text.toString()
//        val note1 = findViewById<EditText>(R.id.1-note).text.toString()
//        // Данные из второй строки
//        val actualValue2 = findViewById<EditText>(R.id.2-actual-value).text.toString()
//        val note2 = findViewById<EditText>(R.id.2-note).text.toString()

    }


}